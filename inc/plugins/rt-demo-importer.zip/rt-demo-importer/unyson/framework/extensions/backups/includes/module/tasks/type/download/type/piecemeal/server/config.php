<?php
/**
 * Overwrite default config
 */

$cfg = array(
	'files' => array(
		// 'demo-id' => '/path/to/demo.zip',
	),
);