<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Digeco_Core;


?>
<div class="rtin-divider">
	<div class="divider-holder">
		<span class="divide-bar"></span>
	</div>
</div>
